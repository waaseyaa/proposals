Waaseyaa Proposals Artifact Bundle
Submission: NorthOps — ISET Self-Employment Assistance
Status: exported
Generated: 2026-04-18T13:21:32+00:00

Included files:
- appendix-a.html
- appendix-f.html
- appendix-g.html
- appendix-m.html
- appendix-b.html
- appendix-h.html
- merged-package.html
- northops-iset-package.pdf

Research-backed field updates:
- None active at bundle generation time.
