Waaseyaa Proposals Artifact Bundle
Submission: Jane Goodowl — Mino-Awiiyaas Catering (Demo)
Status: intake_in_progress
Generated: 2026-04-18T14:52:07+00:00

Included files:
- appendix-a.html
- appendix-b.html
- appendix-f.html
- appendix-g.html
- appendix-h.html
- appendix-m.html
- merged-package.html
- mino-awiiyaas-catering-iset-package.pdf

Research-backed field updates:
- None active at bundle generation time.
