Waaseyaa Proposals Artifact Bundle
Submission: Jane Goodowl — Nookomis Textiles Studio (Demo)
Status: intake_in_progress
Generated: 2026-04-18T02:31:20+00:00

Included files:
- appendix-a.html
- appendix-b.html
- appendix-f.html
- appendix-g.html
- appendix-h.html
- appendix-m.html
- merged-package.html
- nookomis-textiles-studio-iset-package.pdf

Research-backed field updates:
- business.market.marketing_plan <- Band administration offices Local families proposal cohort market (local_corpus)
